Here is completely portable DBreeze v 1.75 and higher.
DBreeze\NETPortable\__Prereq\DBreeze.dll

Can be referenced from .NET Portable library.

To instantiate DBreeze's file system use
DBreeze\NETPortable\__Prereq\FSFactory.cs  
class.

Example in https://github.com/hhblaze/DBreeze/tree/master/NETPortable/__Prereq/App1.zip


